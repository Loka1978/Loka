namespace DragDrop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CreateButton();
        }

        int indexOfButton;
        public void CreateButton()
        {
            for (int buttonCount = 1; buttonCount < 5; buttonCount++)
            {
                Button button = new Button();
                
                button.Location = new Point(30, 30 + buttonCount * 30);
                
                
                button.Text = buttonCount.ToString();
                button.TextAlign = ContentAlignment.MiddleCenter;
                button.Width = 100;
                button.Height = 30;
                button.AllowDrop = true;

                button.MouseEnter += new EventHandler(button_MouseEnter);
                button.MouseDown += new MouseEventHandler(button_MouseDown);
                button.DragEnter += new DragEventHandler(button_DragEnter);
                button.DragDrop += new DragEventHandler(button_DragDrop);
                Controls.Add(button);
            }
        }
        private void button_MouseEnter(object sender, EventArgs e)
        {
            indexOfButton = Controls.IndexOf((Button)sender);
        }

        private void button_MouseDown(object sender, MouseEventArgs e)
        {
            //if (e.Button == MouseButtons.Right)
            ((Button)sender).DoDragDrop(((Button)sender).Text, DragDropEffects.Move);
        }

        private void button_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void button_DragDrop(object sender, DragEventArgs e)
        {
            Controls[indexOfButton].Text = ((Button)sender).Text;
            ((Button)sender).Text = e.Data.GetData(DataFormats.Text).ToString();
        }
    }
}

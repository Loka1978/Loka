﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml.Serialization;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Cars
{
    [XmlRoot("Brand")]
    public class Brand 
    {
        [XmlElement("brandName")]
        public string brandName { get; set; } = string.Empty;
        
        [XmlArray("carModels")]
        [XmlArrayItem("CarModel")]
        public List<CarModel> carModels { get; set; } = new List<CarModel>();
    }

    public class CarModel
    {
        [XmlElement("modelName")]
        public string modelName { get; set; } = string.Empty;
        
        [XmlArray("cars")]
        [XmlArrayItem("Car")]
        public List<Car> cars { get; set; } = new List<Car>();
    }

    public class Car 
    {
        [XmlElement("price")] 
        public double price { get; set; } = 0;
        [XmlElement("date")]
        public DateTime date { get; set; } = DateTime.Now;
        [XmlElement("tax")]
        public double tax { get; set; } = 0;
    }

    public struct WeekendSaleResult
    { 
        public string brand;
        public string model;
        public double priceTotalNoTax;
        public double priceTotalAddTax;
    }
}



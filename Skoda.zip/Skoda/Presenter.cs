﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;
using System.Windows.Forms;
using System.Diagnostics.Eventing.Reader;

namespace Cars
{
    internal class Presenter
    {
        Brand cars = new Brand();
        
        private readonly IView view;
        public Presenter(IView view)
        {
            this.view = view;
            this.view.LoadXML_View += DeserializationModelFromXML;
            this.view.SaveXML_View += SerializationModelToXML;
            this.view.CarInfo_View += CarInfo;
            this.view.WeekendSale_View += CountWeekendSale;
        }

        Brand CarInfo()
        {
            Brand carsToView = cars;
            return carsToView;
        }

        public void SerializationModelToXML()
        {
            Brand carSorted = SaveSortedList(cars);
            string fileName = string.Empty;
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "XML Files (*.xml)|*.xml|All Files (*.*)|*.*",
                Title = "Save file as"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                fileName = saveFileDialog.FileName;
            }

            var serializer = new XmlSerializer(typeof(Brand));
            FileStream fs = null;
            try
            {
                fs = File.Create(fileName);
                XmlWriterSettings settings = new XmlWriterSettings
                {
                    Indent = true
                };
                using (XmlWriter writer = XmlWriter.Create(fs, settings))
                {
                    serializer.Serialize(writer, carSorted);
                }
            }
            finally
            {
                if (fs != null)
                { fs.Dispose(); }
            }
        }
        public void DeserializationModelFromXML()
        {
            cars.carModels.Clear();

            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "XML Files (*.xml)|*.xml|All Files (*.*)|*.*", 
                Title = "Open file"
            };
            string fileName = string.Empty;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                fileName = openFileDialog.FileName;
                string content = File.ReadAllText(fileName);
            }

            FileStream projectLoadStream = null;
            if (!string.IsNullOrEmpty(fileName))
                projectLoadStream = File.OpenRead(fileName);


            if (projectLoadStream != null)
            {
                try
                {
                    XmlReaderSettings settings = new XmlReaderSettings();
                    XmlSerializer serializer = new XmlSerializer(typeof(Brand));
                    using (XmlReader reader = XmlReader.Create(projectLoadStream, settings))
                    {
                        cars = serializer.Deserialize(reader) as Brand;
                    }
                }
                finally
                {
                    if (projectLoadStream != null)
                    { projectLoadStream.Dispose(); }
                }
            }
        }

        public Brand SaveSortedList(Brand brand)
        {
            Brand structuredData = new Brand();

            Dictionary<string, CarModel> dic = new Dictionary<string, CarModel>();

            foreach (var carModel in brand.carModels)
            {
                if (!dic.ContainsKey(carModel.modelName))
                {
                    dic.Add(carModel.modelName, carModel);
                }
                else if (dic.ContainsKey(carModel.modelName))
                {
                    foreach (var car in carModel.cars)
                    {
                        dic[carModel.modelName].cars.Add(car);
                    }
                }
            }
            
            foreach (var record in dic)
            {
                structuredData.carModels.Add(record.Value);
            }
            return structuredData;
        }

        public List<WeekendSaleResult> CountWeekendSale(int a)
        {
            List<WeekendSaleResult> wSaleAll = new List<WeekendSaleResult>();
            Brand structuredData = SaveSortedList(cars);
            foreach (var carModel in structuredData.carModels)
            {
                double priceNoTax = 0;
                double priceTax = 0;
                foreach (var car in carModel.cars)
                {
                    if (car.date.DayOfWeek == DayOfWeek.Saturday || car.date.DayOfWeek == DayOfWeek.Sunday)
                    {
                        priceNoTax = priceNoTax + car.price;
                        priceTax = priceTax + car.tax * 0.01 * car.price + car.price;
                    }
                }

                var wSale = new WeekendSaleResult
                {
                    brand = "Škoda",
                    model = carModel.modelName,
                    priceTotalNoTax = priceNoTax,
                    priceTotalAddTax = priceTax
                };
                wSaleAll.Add(wSale);
            }
            return wSaleAll;
        }
    }
}

namespace ButtonTrida
{
    public partial class Form1 : Form
    {
        int XPosition = 50;
        int Order = 0;
        List<string> OrderButton = new List<string>() {"First", "Second", "Third", "Forth", "Fifth" };
        
        public Form1()
        {
            InitializeComponent();
        }

        void Begin(int XPozice, int Poradi)
        {
            Klasa klasa = new Klasa();
            klasa.MyButton.Size = new Size(75, 50);
            klasa.MyButton.Location = new Point(100 + XPozice, 100);
            klasa.MyButton.Text = OrderButton[Poradi];
            klasa.positionX = klasa.MyButton.Location.X;
            klasa.MyButton.Click += (sender, e) => ClickMe(sender, e, klasa);
            Controls.Add(klasa.MyButton);
        }
        void ClickMe(object sender, EventArgs e, Klasa klasa)
        {
            MessageBox.Show( "X position" + klasa.positionX.ToString() + " I am the " + klasa.MyButton.Text);
            klasa.MyButton.Text = "I am clicked";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Begin(XPosition, Order);
            XPosition = XPosition + 100;
            Order = Order + 1;
        }
    }
}

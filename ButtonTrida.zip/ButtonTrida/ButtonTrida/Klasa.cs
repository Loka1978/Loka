﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ButtonTrida
{
    internal class Klasa
    {
        public Button MyButton = new Button();
        public int positionX { get; set; }
    }
}
